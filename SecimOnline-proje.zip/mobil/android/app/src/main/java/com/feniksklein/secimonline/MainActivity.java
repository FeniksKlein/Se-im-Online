package com.feniksklein.secimonline;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
